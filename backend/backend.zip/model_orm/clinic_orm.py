from backend.biomarker_ranges import CHOICES, RANGES
from backend.dbconnect import db
from backend.model_orm.clinical_vector import ClinicalVector


def _range_checks(table, modality):
    """
    CHECK constraints from backend/biomarker_ranges.py, named the way PostgreSQL names
    them (<table>_<column>_check). create_all() only adds them to NEW tables; existing
    PostgreSQL tables get them from database/migrations/2026-10-15_biomarker_ranges.sql.
    """
    checks = [db.CheckConstraint(f"{col} >= {low} AND {col} <= {high}", name=f"{table}_{col}_check")
              for col, (low, high, _unit) in RANGES[modality].items()]
    for col, allowed in CHOICES.get(modality, {}).items():
        values = ", ".join(f"'{v}'" for v in allowed)
        checks.append(db.CheckConstraint(f"{col} IN ({values})", name=f"{table}_{col}_check"))
    return tuple(checks)

# ==============================================================================
# 1. CORE TRANSACTION & IDEMPOTENCY
# ==============================================================================
class IdempotencyCache(db.Model):
    __tablename__ = 'idempotency_cache'
    
    key = db.Column(db.String(255), primary_key=True)
    data = db.Column(db.JSON, nullable=False)
    status = db.Column(db.Integer, nullable=False)
    timestamp = db.Column(db.Float, nullable=False)


# ==============================================================================
# 2. HEREDITARY RISK & EPIDEMIOLOGICAL STRATIFICATION
# ==============================================================================
class FamilyHistory(db.Model):
    __tablename__ = 'patient_family_history'
    
    record_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.patient_id', ondelete='CASCADE'), nullable=False, index=True)
    
    disease_domain = db.Column(db.String(100), nullable=False)
    specific_diagnosis = db.Column(db.String(150), nullable=False)
    relationship_tier = db.Column(db.String(50), nullable=False)
    relationship_weight = db.Column(db.Numeric, nullable=False)
    onset_classification = db.Column(db.String(50), nullable=False)
    onset_weight = db.Column(db.Numeric, nullable=False)
    age_at_diagnosis = db.Column(db.Integer)
    shared_environment = db.Column(db.Boolean, default=False)
    # S_i in the FHRS formula: verified (records exist) 1.0, unverified 0.5. Only staff set it.
    is_verified = db.Column(db.Boolean, nullable=False, default=False, server_default=db.false())
    recorded_at = db.Column(db.DateTime(timezone=True), server_default=db.func.now())


class EnvironmentalHazard(db.Model):
    """
    A shared domestic hazard (e_j in the FHRS formula) for one disease. hazard_code is a key in
    cdss_spec.json -> fhrs.environmental_hazards.<disease>; its value is read from there.
    """
    __tablename__ = 'patient_environmental_hazards'
    __table_args__ = (db.UniqueConstraint('patient_id', 'disease_domain', 'hazard_code',
                                          name='patient_environmental_hazards_unique'),)

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.patient_id', ondelete='CASCADE'), nullable=False, index=True)
    disease_domain = db.Column(db.String(10), nullable=False)
    hazard_code = db.Column(db.String(50), nullable=False)
    recorded_at = db.Column(db.DateTime(timezone=True), server_default=db.func.now())


class QueueTicket(db.Model):
    """
    One clinic check-in. Numbers restart each day and never repeat within a day; cancelled
    and finished tickets stay as history (status CANCELLED / DONE), so nothing is lost on a
    server restart.
    """
    __tablename__ = 'queue_tickets'
    __table_args__ = (
        db.UniqueConstraint('queue_date', 'queue_number', name='queue_tickets_number_unique'),
        db.CheckConstraint("status IN ('WAITING', 'DONE', 'CANCELLED')", name='queue_tickets_status_check'),
    )

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    queue_date = db.Column(db.Date, nullable=False, index=True)
    queue_number = db.Column(db.Integer, nullable=False)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.patient_id', ondelete='CASCADE'), nullable=False, index=True)
    name = db.Column(db.String(150), nullable=False)
    urgency = db.Column(db.String(40), nullable=False)
    complaint = db.Column(db.Text, nullable=False)
    vitals = db.Column(db.String(255), nullable=False)
    watch_flag = db.Column(db.String(150), nullable=False)
    status = db.Column(db.String(12), nullable=False, default='WAITING')
    checked_in_at = db.Column(db.DateTime(timezone=True), nullable=False)
    closed_at = db.Column(db.DateTime(timezone=True))


class Consultation(db.Model):
    """Directives and notes a doctor records at a visit (previously not saved at all)."""
    __tablename__ = 'consultations'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    consultation_uid = db.Column(db.String(64), unique=True, nullable=False, index=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.patient_id', ondelete='CASCADE'), nullable=False, index=True)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.doctor_id'), nullable=False, index=True)
    directives = db.Column(db.JSON, nullable=False)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False)


class FHRSStratification(db.Model):
    __tablename__ = 'patient_fhrs_stratification'
    
    fhrs_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.patient_id', ondelete='CASCADE'), nullable=False, index=True)
    
    disease_domain = db.Column(db.String(100), nullable=False)
    clustering_score = db.Column(db.Numeric, nullable=False)
    environmental_modifier = db.Column(db.Numeric, nullable=False)
    calculated_fhrs = db.Column(db.Numeric, nullable=False)
    risk_code = db.Column(db.Integer, nullable=False)
    risk_category = db.Column(db.String(50), nullable=False)
    evaluated_at = db.Column(db.DateTime(timezone=True), server_default=db.func.now())


# ==============================================================================
# 3. MODALITY 1: CARDIOVASCULAR DISEASES (patient_cvd_metrics)
# ==============================================================================
class CVDMetrics(db.Model):
    __tablename__ = 'patient_cvd_metrics'
    __table_args__ = _range_checks('patient_cvd_metrics', 'cvd')
    
    metric_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.patient_id', ondelete='CASCADE'), nullable=False, index=True)
    
    age = db.Column(db.Numeric)
    biological_sex = db.Column(db.String(20))
    sbp = db.Column(db.Numeric)
    dbp = db.Column(db.Numeric)
    bmi = db.Column(db.Numeric)
    resting_hr = db.Column(db.Numeric)
    total_cholesterol = db.Column(db.Numeric)
    hdl = db.Column(db.Numeric)
    ldl = db.Column(db.Numeric)
    triglycerides = db.Column(db.Numeric)
    hs_crp = db.Column(db.Numeric)
    serum_creatinine = db.Column(db.Numeric)
    egfr = db.Column(db.Numeric)
    lvef = db.Column(db.Numeric)
    ctni = db.Column(db.Numeric)
    nt_probnp = db.Column(db.Numeric)
    smoking_history = db.Column(db.Numeric)
    daily_sodium = db.Column(db.Numeric)
    family_history_premature_cvd = db.Column(db.Integer)
    physical_activity = db.Column(db.Numeric)
    recorded_at = db.Column(db.DateTime(timezone=True), server_default=db.func.now())


# ==============================================================================
# 4. MODALITY 2: TYPE 2 DIABETES (patient_t2d_metrics)
# ==============================================================================
class T2DMetrics(db.Model):
    __tablename__ = 'patient_t2d_metrics'
    __table_args__ = _range_checks('patient_t2d_metrics', 't2d')
    
    metric_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.patient_id', ondelete='CASCADE'), nullable=False, index=True)
    
    fpg = db.Column(db.Numeric(5, 1))
    postprandial_glucose_2h = db.Column(db.Numeric(5, 1))
    hba1c = db.Column(db.Numeric(4, 1))
    fasting_insulin = db.Column(db.Numeric(5, 1))
    c_peptide = db.Column(db.Numeric(4, 1))
    homa_ir = db.Column(db.Numeric(4, 1))
    bmi = db.Column(db.Numeric(4, 1))
    waist_circumference = db.Column(db.Numeric(5, 1))
    whr = db.Column(db.Numeric(4, 2))
    sbp = db.Column(db.Numeric(5, 1))
    dbp = db.Column(db.Numeric(5, 1))
    triglycerides = db.Column(db.Numeric(6, 1))
    hdl = db.Column(db.Numeric(5, 1))
    uacr = db.Column(db.Numeric(6, 1))
    serum_uric_acid = db.Column(db.Numeric(4, 1))
    gestational_diabetes = db.Column(db.Integer)
    family_history_diabetes = db.Column(db.Integer)
    acanthosis_nigricans = db.Column(db.Integer)
    daily_carbs = db.Column(db.Numeric(5, 1))
    sedentary_duration = db.Column(db.Numeric(4, 1))
    recorded_at = db.Column(db.DateTime(timezone=True), server_default=db.func.now())


# ==============================================================================
# 5. MODALITY 3: RESPIRATORY (patient_respiratory_metrics)
# ==============================================================================
class RespiratoryMetrics(db.Model):
    __tablename__ = 'patient_respiratory_metrics'
    __table_args__ = _range_checks('patient_respiratory_metrics', 'resp')
    
    metric_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.patient_id', ondelete='CASCADE'), nullable=False, index=True)
    
    fev1 = db.Column(db.Numeric(3, 1))
    fvc = db.Column(db.Numeric(3, 1))
    fev1_fvc_ratio = db.Column(db.Numeric(4, 1))
    post_bd_fev1_pred = db.Column(db.Numeric(5, 1))
    pef = db.Column(db.Numeric(5, 1))
    eosinophil_count = db.Column(db.Numeric(6, 1))
    feno = db.Column(db.Numeric(5, 1))
    spo2 = db.Column(db.Numeric(4, 1))
    pao2 = db.Column(db.Numeric(5, 1))
    paco2 = db.Column(db.Numeric(4, 1))
    mmrc_score = db.Column(db.Integer)
    act_score = db.Column(db.Integer)
    cat_score = db.Column(db.Integer)
    serum_ige = db.Column(db.Numeric(6, 1))
    annual_exacerbations = db.Column(db.Integer)
    tobacco_exposure = db.Column(db.Numeric(5, 1))
    occupational_dust = db.Column(db.Integer)
    allergic_rhinitis = db.Column(db.Integer)
    childhood_asthma = db.Column(db.Integer)
    bmi = db.Column(db.Numeric(4, 1))
    recorded_at = db.Column(db.DateTime(timezone=True), server_default=db.func.now())


# ==============================================================================
# 6. MODALITY 4: NEUROLOGICAL & MENTAL (patient_neuro_mental_metrics)
# ==============================================================================
class NeuroMentalMetrics(db.Model):
    __tablename__ = 'patient_neuro_mental_metrics'
    __table_args__ = _range_checks('patient_neuro_mental_metrics', 'neuro')
    
    metric_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.patient_id', ondelete='CASCADE'), nullable=False, index=True)
    
    phq9 = db.Column(db.Integer)
    gad7 = db.Column(db.Integer)
    mmse = db.Column(db.Integer)
    moca = db.Column(db.Integer)
    ham_d = db.Column(db.Integer)
    updrs_part3 = db.Column(db.Integer)
    daily_sleep = db.Column(db.Numeric(4, 1))
    psqi = db.Column(db.Integer)
    seizure_frequency = db.Column(db.Numeric(5, 1))
    hrv_sdnn = db.Column(db.Numeric(5, 1))
    serum_cortisol = db.Column(db.Numeric(4, 1))
    vitamin_b12 = db.Column(db.Numeric(6, 1))
    serum_folate = db.Column(db.Numeric(4, 1))
    tsh = db.Column(db.Numeric(5, 2))
    faq_score = db.Column(db.Integer)
    tremor_rating = db.Column(db.Integer)
    tbi_history = db.Column(db.Integer)
    substance_abuse = db.Column(db.Integer)
    family_history_neuro_psych = db.Column(db.Integer)
    age = db.Column(db.Numeric(4, 1))
    recorded_at = db.Column(db.DateTime(timezone=True), server_default=db.func.now())


# ==============================================================================
# 7. CORE ENCOUNTER & LONGITUDINAL LEDGER (D3)
# ==============================================================================
class Encounter(db.Model):
    __tablename__ = 'encounters'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    encounter_uid = db.Column(db.String(64), unique=True, nullable=False, index=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.patient_id', ondelete='CASCADE'), nullable=False, index=True)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.doctor_id'), nullable=False)
    
    # Discriminator: 'BASELINE', 'FOLLOWUP', 'REANCHOR_BASELINE'
    record_type = db.Column(db.String(32), nullable=False, default='BASELINE')
    
    # Cryptographic Chain & Provenance
    parent_baseline_hash = db.Column(db.String(64), nullable=True)
    cryptographic_hash = db.Column(db.String(64), nullable=False, unique=True, index=True)
    
    # Snapshots & Directives
    cdss_payload = db.Column(db.JSON, nullable=False)
    care_plan = db.Column(db.JSON, nullable=False)
    reanchor_decision = db.Column(db.String(16), nullable=True)
    
    created_at_utc = db.Column(db.DateTime(timezone=True), server_default=db.func.now(), nullable=False)

    # Relationships
    patient = db.relationship('Patient', backref=db.backref('encounters', lazy=True, cascade='all, delete-orphan'))
    doctor = db.relationship('Doctor', backref=db.backref('authored_encounters', lazy=True))

    # Contract Compatibility Alias
    @property
    def cdss_payload_snapshot(self):
        """Attribute alias for API contract compatibility."""
        return self.cdss_payload

    @cdss_payload_snapshot.setter
    def cdss_payload_snapshot(self, value):
        self.cdss_payload = value